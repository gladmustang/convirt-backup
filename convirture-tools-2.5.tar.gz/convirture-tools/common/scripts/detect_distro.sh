source common/scripts/functions 
detect_distro 
echo "name=${DIST};version=${VER}"
