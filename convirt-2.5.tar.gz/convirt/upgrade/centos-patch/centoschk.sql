show create table emailsetup
