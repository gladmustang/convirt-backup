ALTER TABLE `tasks` MODIFY COLUMN entity_type int(11) DEFAULT NULL;


