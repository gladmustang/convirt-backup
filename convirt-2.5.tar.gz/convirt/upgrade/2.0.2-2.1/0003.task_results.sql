ALTER TABLE `task_results` MODIFY COLUMN `results` mediumblob;
