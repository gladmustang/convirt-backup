alter table `deployment` add column registered tinyint(1) DEFAULT 0;
