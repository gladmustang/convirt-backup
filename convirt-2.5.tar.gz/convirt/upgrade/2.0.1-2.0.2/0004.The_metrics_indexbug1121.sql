alter table metrics add index `m_rype_cdate` (`metric_type`,`cdate`)
