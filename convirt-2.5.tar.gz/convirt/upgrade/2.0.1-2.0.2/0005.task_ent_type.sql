ALTER TABLE `tasks` ADD COLUMN `entity_type` varchar(255) DEFAULT NULL,
 ADD COLUMN `short_desc` TEXT ,
 ADD COLUMN `long_desc` TEXT ;
