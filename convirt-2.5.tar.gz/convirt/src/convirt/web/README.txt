This directory contains the turbogears2 environment.
Install tg2env and link the convirt directory under it.
