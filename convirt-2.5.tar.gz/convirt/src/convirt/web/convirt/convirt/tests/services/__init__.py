# -*- coding: utf-8 -*-
"""Functional test suite for the services code."""
